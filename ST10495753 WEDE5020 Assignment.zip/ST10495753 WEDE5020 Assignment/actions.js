
document.querySelector("button").addEventListener("click", () => {
  alert("Redirecting to Nike's best deals!");
});
const logos = document.querySelectorAll(".logos");
logos.forEach((logo) => {
  logo.addEventListener("mouseover", () => {
    logo.style.transform = "rotate(10deg)";
    logo.style.transition = "transform 0.3s ease";
  });

  logo.addEventListener("mouseout", () => {
    logo.style.transform = "rotate(0deg)";
  });
});

document.getElementById("darkModeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

window.onload = () => {
  const title = document.querySelector('h1');
  title.style.transition = 'all 1s ease';
  title.style.transform = 'scale(1.o)';
  title.style.color = '#e74c3c'; // Nike red
};

document.addEventListener('DOMContentLoaded', () => {
  const firstParagraph = document.querySelector('p');

  const counter = document.createElement('p');
  counter.innerHTML = 'Global Stores: <span id="storeCount">0</span>';
  counter.style.marginTop = '10px';
  firstParagraph.parentNode.insertBefore(counter, firstParagraph.nextSibling);

  let count = 0;
  const storeCount = counter.querySelector('#storeCount');
  const interval = setInterval(() => {
    count++;
    storeCount.textContent = count;
    if (count >= 1180) clearInterval(interval);
  }, 5);
});
